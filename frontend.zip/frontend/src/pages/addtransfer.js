import { useState, setState, useEffect } from "react";
import MenuItem from "@material-ui/core/MenuItem";
import { Navigate } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import http from "../http";


export default function AddTransfer(){
    const navigate = useNavigate();
    const [inputs, setInputs, setState, selects, setSelects] = useState({});
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values,[name]:value}));
       
    }
    const [passengers, setUsers ] = useState([]);
    const [vehicles, setVehicles ] = useState([]);



    useEffect(()=>{
        fetchAllUsers();
    },[]);
    
    const fetchAllUsers = () => {
        http.get('/passenger').then(res=>{
            setUsers(res.data);
        })
        http.get('/vehicle').then(res=>{
            setVehicles(res.data);
        })
    }
   

    const submitForm = () => {
        http.post('/addtransfer', inputs).then((res)=>{
            if(res.data){
                navigate('/transfer');
            }else {
                console.log('Fill all fields');
            }
        })
    }
    return (
        <div className="card p-4">
            <h2>Add Transfers</h2>
            
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Start Point: </label>
                <div className="col-sm-10">
                    <input type="text" placeholder="Enter Start Point" name="startpoint" className="form-control"
                        value={inputs.startpoint || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">End Point: </label>
                <div className="col-sm-10">
                    
                    <input type="text" placeholder="Enter End Point" name="endpoint" className="form-control"
                        value={inputs.endpoint || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Departure Date: </label>
                <div className="col-sm-10">
                    
                    <input type="date" name="depdate" className="form-control"
                        value={inputs.depdate || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row" data-provide="datepicker">
                <label  className="col-sm-2 col-form-label">Departure Time: </label>
                <div className="col-sm-10">
                    <input type="time" name="deptime" className="form-control"
                        value={inputs.deptime || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Select Vehicle : </label>
                <div className="col-sm-10">
                    <select className="form-select" name="sltvehicle" id="" value={inputs.sltvehicle || ''}
                        onChange={(event)=>handleChange(event)}>
                            <option value="">Select Vehicle</option>
                        {vehicles.map((vehicle,index)=>(
                                <option value={vehicle.id} key={vehicle.id}> {vehicle.vehicle_name} </option>
                            ))}
                    </select>
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Select Passenger: </label>
                <div className="col-sm-10">
                    <select  className="form-select" name="sltpassenger" id="" value={inputs.sltpassenger || ''}
                        onChange={(event)=>handleChange(event)}>
                        <option value="">Select Passenger</option>
                            {passengers.map((passenger,index)=>(
                                <option value={passenger.id} key={passenger.id}> {passenger.p_name} </option>
                            ))}
                    </select>
                </div>
            </div>
            <div className="mb-3 row">
                <div className="col-sm-10">
                    <input type="submit" onClick={submitForm} value="Save" className="btn btn-primary" />
                </div>
            </div>
        </div>
    )
}