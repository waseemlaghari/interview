import { useState, setState } from "react";
import { Navigate } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import http from "../http";


export default function AddVehicle(){
    const navigate = useNavigate();
    const [inputs, setInputs, setState, selects, setSelects] = useState({});
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values,[name]:value}));
       
    }

    const submitForm = () => {
        http.post('/addvehicle', inputs).then((res)=>{
            if(res.data){
                navigate('/vehicle');
            }else {
                console.log('Fill all fields');
            }
        })
    }
    return (
        <div className="card p-4">
            <h2>Add Vehicle</h2>
            
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Vehicle Name: </label>
                <div className="col-sm-10">
                    
                    <input type="text" placeholder="Enter Vehicle Name" name="vehiclename" className="form-control"
                        value={inputs.vehiclename || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Vehicle Number: </label>
                <div className="col-sm-10">
                    <input type="text" placeholder="Enter Vehicle Number" name="vehiclenumber" className="form-control" id="inputsurname" 
                        value={inputs.vehiclenumber || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Driver Name: </label>
                <div className="col-sm-10">
                <input type="text" placeholder="Enter Driver Name" name="drivername" className="form-control" id="inputnumber" 
                    value={inputs.drivername || ''}
                    onChange={handleChange}
                />
                </div>
            </div>
            <div className="mb-4 row">
                <label className="col-sm-2 col-form-label">Driver Surname: </label>
                <div className="col-sm-10">
                    <input type="text" placeholder="Enter Driver Surname" name="driversurname" className="form-control" id="inputnumber" 
                        value={inputs.driversurname || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-3 row">
                <div className="col-sm-10">
                    <input type="submit" onClick={submitForm} value="Save" className="btn btn-primary" />
                </div>
            </div>
        </div>
    )
}