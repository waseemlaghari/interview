import { useState, useEffect } from 'react'
import http from '../http'
import {Routes, Route, Link} from 'react-router-dom'

export default function Vehicle(){
    const [vehicles, setUsers] = useState([]);

    useEffect(()=>{
        fetchAllUsers();
    },[]);
    
    const fetchAllUsers = () => {
        http.get('/vehicle').then(res=>{
            setUsers(res.data);
        })
    }
    
    const deleteVehicle = (id) => {
        http.delete('/vehicle/'+id).then(res=>{
            fetchAllUsers();
        })
    }
    return (
        <div>
            <h2>Vehicles</h2>
            <Link to={"/addvehicle"} className="btn btn-primary">Add Vehicle</Link>
            <table className="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Vehicle Name</th>
                    <th scope="col">Vehicle Number</th>
                    <th scope="col">Driver Name</th>
                    <th scope="col">Driver Surname</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {vehicles.map((vehicle,index)=>(
                        <tr key={vehicle.id}>
                            <td>{++index}</td>
                            <td>{vehicle.vehicle_name}</td>
                            <td>{vehicle.vehicle_number}</td>
                            <td>{vehicle.driver_name}</td>
                            <td>{vehicle.driver_surname}</td>
                            <td>
                                <Link to={{ pathname:"/editvehicle/"+vehicle.id }} className="btn btn-info">
                                    Edit
                                </Link>
                            </td>
                            <td>
                                <button type="button" className='btn btn-danger'
                                    onClick={()=>deleteVehicle(vehicle.id)}
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                
                </tbody>
            </table>
        </div>
    )
}