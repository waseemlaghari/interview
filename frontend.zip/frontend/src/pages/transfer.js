import { useState, useEffect } from 'react'
import http from '../http'
import {Routes, Route, Link} from 'react-router-dom'

export default function Transfer(){
    const [transfers, setUsers] = useState([]);

    useEffect(()=>{
        fetchAllUsers();
    },[]);
    
    const fetchAllUsers = () => {
        http.get('/transfer').then(res=>{
            setUsers(res.data['transfer']);
        }) 
    }
    
    // const deletePassenger = (t_id) => {
    //     http.delete('/transfer/'+t_id).then(res=>{
    //         fetchAllUsers();
    //     })
    // }
    return (
        <div>
            <h2>Transfers</h2>
            <Link to={"/addtransfer"} className="btn btn-primary">Add Transfer</Link>
            <table className="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Passenger Name</th>
                    <th scope="col">Vehicle Name</th>
                    <th scope="col">Driver Name</th>
                    <th scope="col">Departure Date</th>
                    <th scope="col">Departure Time</th>
                    <th scope="col">Start Point</th>
                    <th scope="col">End Point</th>
                    <th scope="col">Edit</th>
                    </tr>
                </thead>
                <tbody>
                    {transfers.map((transfer,index)=>(
                        <tr key={transfer.t_id}>
                            <td>{++index}</td>
                            <td>{transfer.p_name}</td>
                            <td>{transfer.vehicle_name}</td>
                            <td>{transfer.driver_name}</td>
                            <td>{transfer.departure_date}</td>
                            <td>{transfer.departure_time}</td>
                            <td>{transfer.start_point}</td>
                            <td>{transfer.end_point}</td>
                            
                            <td>
                                <Link to={{ pathname:"/edittransfer/"+transfer.t_id }} className="btn btn-info">
                                    Edit
                                </Link>
                            </td>
                        </tr>
                    ))}
                
                </tbody>
            </table>
        </div>
    )
}