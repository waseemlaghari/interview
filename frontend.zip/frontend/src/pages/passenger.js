import { useState, useEffect } from 'react'
import http from '../http'
import {Routes, Route, Link} from 'react-router-dom'

export default function Passenger(){
    const [passengers, setUsers] = useState([]);
    const [inputs, setInputs ] = useState({});

    useEffect(()=>{
        fetchAllUsers();
    },[]);
    
    const fetchAllUsers = () => {
        http.get('/passenger').then(res=>{
            setUsers(res.data);
            // if(event > 0){
            //     setInputs({
            //         type: event,
            //     })
            // }
            // else {
            //     setInputs({
            //         type: event,
            //     }) 
            // }
            
        })
    }
    
    const deletePassenger = (id) => {
        http.delete('/passenger/'+id).then(res=>{
            fetchAllUsers();
        })
    }
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({ ...values, [name]: value }));
       
        fetchAllUsers(value);
        
    }
    return (
        <div>
            <h2>Passengers</h2>
            <Link to={"/addpassenger"} className="btn btn-primary">Add Passenger</Link>
            {/* <select name="type"  className="form-select customsetting" id=""
                value={inputs.type || '0'}
                onChange={(event)=>handleChange(event)}
                >
                <option value="0"> Filter By </option>
                <option value="1"> Patient </option>
                <option value="2"> Hospital Stuff </option>
            </select> */}
            <table className="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Surname</th>
                    <th scope="col">Number</th>
                    <th scope="col">Type</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {passengers.map((passenger,index)=>(
                        <tr key={passenger.id}>
                            <td>{++index}</td>
                            <td>{passenger.p_name}</td>
                            <td>{passenger.p_surname}</td>
                            <td>{passenger.p_number}</td>
                            <td>
                            {passenger.p_type == 1
                            ? "Patient"
                            : "Hospital Stuff"
                            }
                                {/* {if(passenger.p_type == 1)
                                    Patient
                                } */}
                                {/* { passenger.p_type == 0 ? } */}
                                {/* // {passenger.p_type} */}
                            </td>
                            <td>
                                <Link to={{ pathname:"/editpassenger/"+passenger.id }} className="btn btn-info">
                                    Edit
                                </Link>
                            </td>
                            <td>
                                <button type="button" className='btn btn-danger'
                                    onClick={()=>deletePassenger(passenger.id)}
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                
                </tbody>
            </table>
        </div>
    )
}