import { useState, setState } from "react";
import { Navigate } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import http from "../http";


export default function Passenger(){
    const navigate = useNavigate();
    const [inputs, setInputs, setState, selects, setSelects] = useState({});
    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({...values,[name]:value}));
       
    }

    const submitForm = () => {
        http.post('/addpassenger', inputs).then((res)=>{
            if(res.data){
                navigate('/');
            }else {
                console.log('Fill all fields');
            }
        })
    }
    return (
        <div className="card p-4">
            <h2>Add Passenger</h2>
            
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Name: </label>
                <div className="col-sm-10">
                    
                    <input type="text" placeholder="Enter Passenger Name" name="name" className="form-control"
                        value={inputs.name || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Surname: </label>
                <div className="col-sm-10">
                    <input type="text" placeholder="Enter Passenger SurName" name="surname" className="form-control" id="inputsurname" 
                        value={inputs.surname || ''}
                        onChange={handleChange}
                    />
                </div>
            </div>
            <div className="mb-4 row">
                <label  className="col-sm-2 col-form-label">Number: </label>
                <div className="col-sm-10">
                <input type="text" placeholder="Enter Passenger Phone Number" name="number" className="form-control" id="inputnumber" 
                    value={inputs.number || ''}
                    onChange={handleChange}
                />
                </div>
            </div>
            <div className="mb-4 row">
                <label className="col-sm-2 col-form-label">Type: </label>
                <div className="col-sm-10">
                    
                    <select name="type"  className="form-select" id="" value={selects}
                        onChange={(event)=>handleChange(event)}>
                        <option value=""> Select </option>
                        <option value="1"> Patient </option>
                        <option value="2"> Hospital Stuff </option>
                    </select>
                </div>
            </div>
            <div className="mb-3 row">
                <div className="col-sm-10">
                    <input type="submit" onClick={submitForm} value="Save" className="btn btn-primary" />
                </div>
            </div>
        </div>
    )
}