import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Routes, Route, Link} from 'react-router-dom'
import Passenger from './pages/passenger'
import AddPassenger from './pages/addpassenger'
import EditPassenger from './pages/editpassenger'
import Vehicle from './pages/vehicle'
import AddVehicle from './pages/addvehicle'
import EditVehicle from './pages/editvehicle'
import Transfer from './pages/transfer'
import AddTransfer from './pages/addtransfer'
import EditTransfer from './pages/edittransfer'

function App() {
  return (
    <div>
      <div className='navbar navbar-expand navbar-dark bg-dark'>
        <div className='navbar-nav mr-auto'>
          <li className='nav-item'>
            <Link to={"/"} className="nav-link">Passenger</Link>
          </li>
          <li className='nav-item'>
            <Link to={"/vehicle"} className="nav-link">Vehicle</Link>
          </li>
          <li className='nav-item'>
            <Link to={"/transfer"} className="nav-link">Transfer</Link>
          </li>
        </div>
      </div>
      <div className='container'>
        <Routes>
          <Route path='/' element={<Passenger />} />
          <Route path='/addpassenger' element={<AddPassenger />} />
          <Route path='/editpassenger/:id' element={<EditPassenger />} />
          <Route path='/vehicle' element={<Vehicle />} />
          <Route path='/addvehicle' element={<AddVehicle />} />
          <Route path='/editvehicle/:id' element={<EditVehicle />} />
          <Route path='/transfer' element={<Transfer />} />
          <Route path='/addtransfer' element={<AddTransfer />} />
          <Route path='/edittransfer/:t_id' element={<EditTransfer />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
